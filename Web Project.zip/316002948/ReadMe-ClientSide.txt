My application is a social platform that helps parents find the best babysitter for their child
based on their preferences and location.

--Home Page--
The home page contains the following elements:
* navigation bar with the following tabs: Home,About Us,Contact Us
* two validated input fields: Email,Password (for existing clients).
* two buttons- sign in (for existing clients) and sign up (for new clients).
* animation - Images change in the background by animation

--Sign Up Page--
The client chooses whether to register as a parent or to register as a babysitter

--Sign Up - Parent Profile Page--
there are 3 validated input fields : email , password , repete password.
By clicking on one of the fields, the form expands

--Find Your Match Page--
the client chooses wether to find a match by location or to show all 

--My Matches Page--
display icons of potentioal babysitters based on the user's personal information preferences/
each profile contains profile image, description such as age,address and availability.
Additional functionality on this page - finding the nearest babysitter using geolocation,
After the user approves the location services, the function calculates the distance of each of the babysitters
and pops a message to the client with the nearest babysitter.
